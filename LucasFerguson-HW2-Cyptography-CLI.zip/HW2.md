Task 1: True/False Questions
1. Cryptanalysis is the process of creating secret messages to protect information. (True / False)
2. A symmetric cryptosystem uses the same key for both encryption and decryption.(True / False)
3. Kerckhoffs' Principle states that the security of a cryptosystem should rely on the secrecy of the
algorithm rather than the key. (True / False)
1. In a transposition cipher, letters in the plaintext are replaced by other letters. (True / False)
2. A known plaintext attack requires the attacker to have access to both plaintext and corresponding
ciphertext pairs. (True / False)
1. The Vigenère cipher is a polyalphabetic substitution cipher. (True / False)
2. The one-time pad provides perfect secrecy if the key is truly random and used only once.
(True / False)
1. A brute-force attack on a cipher involves trying all possible keys until the correct one is found.
(True / False)
1. Frequency analysis is ineffective against monoalphabetic substitution ciphers. (True / False)
2. A block cipher encrypts one bit at a time, similar to a stream cipher. (True / False)
3. The main weakness of the one-time pad is that it requires the key to be the same length as the
message. (True / False)
1. A chosen ciphertext attack allows an attacker to select ciphertexts and obtain their corresponding
plaintexts.(True / False)
1. The shift cipher is a type of transposition cipher.(True / False)
2. Computationally secure encryption means that an attacker cannot break the encryption within a
practical time frame. (True / False)
1. The Vernam cipher is another name for the Vigenère cipher. (True / False)


